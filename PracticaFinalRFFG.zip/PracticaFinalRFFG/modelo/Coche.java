package modelo;

public class Coche {
    private int id;
    private String marca;
    private String modelo;
    private String matricula;
    private String color;
    private int annio;

    public Coche(String marca, String modelo, String matricula, String color, int annio) {
        this.marca = marca;
        this.modelo = modelo;
        this.matricula = matricula;
        this.color = color;
        this.annio = annio;
    }

    public int getId() { return id; }
    public String getMarca() { return marca; }
    public String getModelo() { return modelo; }
    public String getMatricula() { return matricula; }
    public String getColor() { return color; }
    public int getAnnio() { return annio; }
}
