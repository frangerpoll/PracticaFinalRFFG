package controlador;

import modelo.Coche;
import utilidades.ConexionBD;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public class ControladorCoche {

    public static boolean crearCoche(Coche coche, String uuidPropietario) {
        String sqlCoche = "INSERT INTO coches (marca, modelo, matricula, color, annio) VALUES (?, ?, ?, ?, ?)";
        String sqlRelacion = "INSERT INTO usuarios_coches (usuario_uuid, coche_id) VALUES (?, ?)";

        try (Connection conn = ConexionBD.conectar()) {
            conn.setAutoCommit(false);

            try (PreparedStatement stmtCoche = conn.prepareStatement(sqlCoche, PreparedStatement.RETURN_GENERATED_KEYS)) {
                stmtCoche.setString(1, coche.getMarca());
                stmtCoche.setString(2, coche.getModelo());
                stmtCoche.setString(3, coche.getMatricula());
                stmtCoche.setString(4, coche.getColor());
                stmtCoche.setInt(5, coche.getAnnio());
                stmtCoche.executeUpdate();

                var generatedKeys = stmtCoche.getGeneratedKeys();
                if (generatedKeys.next()) {
                    int cocheId = generatedKeys.getInt(1);
                    try (PreparedStatement stmtRelacion = conn.prepareStatement(sqlRelacion)) {
                        stmtRelacion.setString(1, uuidPropietario);
                        stmtRelacion.setInt(2, cocheId);
                        stmtRelacion.executeUpdate();
                        conn.commit();
                        return true;
                    }
                }
            }
            conn.rollback();
        } catch (SQLException e) {
            System.err.println("Error al crear coche: " + e.getMessage());
        }
        return false;
    }
}
