package vista;

import modelo.Usuario;
import controlador.ControladorUsuario;

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class VentanaRegistro extends JFrame {
    private JTextField campoNombre;
    private JPasswordField campoContrasena;
    private JButton botonRegistrar;

    public VentanaRegistro() {
        setTitle("Registro de Usuario");
        setSize(300, 200);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setLayout(null);

        JLabel etiquetaNombre = new JLabel("Nombre:");
        etiquetaNombre.setBounds(20, 20, 80, 25);
        add(etiquetaNombre);

        campoNombre = new JTextField();
        campoNombre.setBounds(100, 20, 160, 25);
        add(campoNombre);

        JLabel etiquetaContrasena = new JLabel("Contraseña:");
        etiquetaContrasena.setBounds(20, 60, 80, 25);
        add(etiquetaContrasena);

        campoContrasena = new JPasswordField();
        campoContrasena.setBounds(100, 60, 160, 25);
        add(campoContrasena);

        botonRegistrar = new JButton("Registrar");
        botonRegistrar.setBounds(90, 100, 100, 30);
        add(botonRegistrar);
        
        botonRegistrar.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String nombre = campoNombre.getText();
                String contrasena = new String(campoContrasena.getPassword());

                if (!nombre.isEmpty() && !contrasena.isEmpty()) {
                    Usuario usuario = new Usuario(nombre, contrasena);
                    boolean exito = ControladorUsuario.registrarUsuario(usuario);
                    if (exito) {
                        JOptionPane.showMessageDialog(null, "Registrado. UUID:\n" + usuario.getUuid());
                    } else {
                        JOptionPane.showMessageDialog(null, "Error al registrar.");
                    }
                } else {
                    JOptionPane.showMessageDialog(null, "Rellena todos los campos.");
                }
            }
        });
     
    }
}
