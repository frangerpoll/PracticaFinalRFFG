package utilidades;

public class Validador {

    /**
     * Verifica si una cadena está vacía o es null.
     * @param texto Texto a comprobar.
     * @return true si está vacío o null, false si tiene contenido.
     */
    public static boolean estaVacio(String texto) {
        return texto == null || texto.trim().isEmpty();
    }

    /**
     * Verifica si una cadena es un número entero válido.
     */
    public static boolean esEntero(String texto) {
        try {
            Integer.parseInt(texto.trim());
            return true;
        } catch (NumberFormatException e) {
            return false;
        }
    }

    /**
     * Verifica si una cadena es un número decimal válido.
     */
    public static boolean esDecimal(String texto) {
        try {
            Double.parseDouble(texto.trim());
            return true;
        } catch (NumberFormatException e) {
            return false;
        }
    }
}
