package utilidades;

import javax.swing.*;

public class GestorErrores {

    public static void mostrarErrorConexion() {
        JOptionPane.showMessageDialog(null,
            "❌ Error al conectar con la base de datos.\n" +
            "Por favor, revisa el archivo .env o asegúrate de que el servidor MySQL está activo.",
            "Error de Conexión",
            JOptionPane.ERROR_MESSAGE);
    }

    public static void mostrarError(String titulo, String mensaje) {
        JOptionPane.showMessageDialog(null,
            mensaje,
            titulo,
            JOptionPane.ERROR_MESSAGE);
    }

    public static void mostrarInfo(String titulo, String mensaje) {
        JOptionPane.showMessageDialog(null,
            mensaje,
            titulo,
            JOptionPane.INFORMATION_MESSAGE);
    }

    public static void mostrarAdvertencia(String titulo, String mensaje) {
        JOptionPane.showMessageDialog(null,
            mensaje,
            titulo,
            JOptionPane.WARNING_MESSAGE);
    }
}
