package utilidades;

import modelo.DatabaseConnection;

import java.io.IOException;
import java.sql.Connection;
import java.sql.SQLException;

public class ConexionBD {
    public static Connection conectar() {
        try {
            return DatabaseConnection.getConnection();
        } catch (ClassNotFoundException | SQLException | IOException e) {
            System.err.println("❌ Error al conectar a la base de datos: " + e.getMessage());
            return null;
        }
    }
}
