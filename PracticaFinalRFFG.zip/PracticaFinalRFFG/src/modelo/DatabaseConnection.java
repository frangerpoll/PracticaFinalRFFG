package modelo;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

import utilidades.Configurations;
import utilidades.DatabaseConfigurations;

public class DatabaseConnection {
	
	public static Connection getConnection() throws ClassNotFoundException, SQLException, IOException {
	    DatabaseConfigurations dbConfigs = Configurations.getInstance().getDatabaseConfigurations();

	    // Cargar el driver JDBC de MySQL
	    Class.forName("com.mysql.cj.jdbc.Driver");

	    // Construir la URL de conexión
	    String connectionUrl = "jdbc:mysql://" + dbConfigs.getHost() + ":" + dbConfigs.getPort() + "/" + dbConfigs.getDatabase();

	    // Establecer una nueva conexión cada vez
	    return DriverManager.getConnection(connectionUrl, dbConfigs.getUsername(), dbConfigs.getPassword());
	}

}
