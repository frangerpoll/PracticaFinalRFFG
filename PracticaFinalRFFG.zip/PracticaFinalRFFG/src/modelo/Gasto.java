package modelo;

public class Gasto {
    private String tipo;
    private int kilometraje;
    private String fecha;
    private double importe;
    private String descripcion;

    public Gasto(String tipo, int kilometraje, String fecha, double importe, String descripcion) {
        this.tipo = tipo;
        this.kilometraje = kilometraje;
        this.fecha = fecha;
        this.importe = importe;
        this.descripcion = descripcion;
    }

    public String getTipo() { return tipo; }
    public int getKilometraje() { return kilometraje; }
    public String getFecha() { return fecha; }
    public double getImporte() { return importe; }
    public String getDescripcion() { return descripcion; }
}
