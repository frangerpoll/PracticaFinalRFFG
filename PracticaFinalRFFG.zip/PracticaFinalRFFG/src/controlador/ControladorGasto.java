package controlador;

import modelo.Gasto;
import utilidades.ConexionBD;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class ControladorGasto {

    public static boolean crearGasto(int cocheId, String tipo, int kilometraje, String fecha, double importe, String descripcion) {
        String sql = """
                INSERT INTO gastos (coche_id, tipo, kilometraje, fecha_gasto, importe, descripcion)
                VALUES (?, ?, ?, ?, ?, ?)
                """;

        try (Connection conn = ConexionBD.conectar();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setInt(1, cocheId);
            stmt.setString(2, tipo);
            stmt.setInt(3, kilometraje);
            stmt.setString(4, fecha);
            stmt.setDouble(5, importe);
            stmt.setString(6, descripcion);
            stmt.executeUpdate();

            return true;
        } catch (SQLException e) {
            System.err.println("Error al guardar gasto: " + e.getMessage());
            return false;
        }
    }

    public static List<Gasto> obtenerGastosPorCoche(String matricula) {
        List<Gasto> lista = new ArrayList<>();

        String sql = """
            SELECT g.tipo, g.kilometraje, g.fecha_gasto, g.importe, g.descripcion
            FROM gastos g
            JOIN coches c ON g.coche_id = c.id
            WHERE c.matricula = ?
            """;

        try (Connection conn = ConexionBD.conectar();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setString(1, matricula);
            ResultSet rs = stmt.executeQuery();

            while (rs.next()) {
                Gasto g = new Gasto(
                    rs.getString("tipo"),
                    rs.getInt("kilometraje"),
                    rs.getString("fecha_gasto"),
                    rs.getDouble("importe"),
                    rs.getString("descripcion")
                );
                lista.add(g);
            }

        } catch (SQLException e) {
            System.err.println("Error al obtener gastos: " + e.getMessage());
        }

        return lista;
    }
}
