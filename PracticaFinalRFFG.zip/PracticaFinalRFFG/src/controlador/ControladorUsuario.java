package controlador;

import modelo.DatabaseConnection;
import modelo.Usuario;
import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public class ControladorUsuario {

    public static boolean registrarUsuario(Usuario usuario) {
        String sql = "INSERT INTO usuarios (uuid, nombre, contrasena) VALUES (?, ?, ?)";
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setString(1, usuario.getUuid());
            stmt.setString(2, usuario.getNombre());
            stmt.setString(3, usuario.getContrasena());
            stmt.executeUpdate();
            return true;
        } catch (SQLException | ClassNotFoundException | IOException e) {
            System.err.println("Error al registrar usuario: " + e.getMessage());
            return false;
        }
    }

    public static Usuario iniciarSesion(String nombre, String contrasena) {
        String sql = "SELECT uuid, nombre, contrasena FROM usuarios WHERE nombre = ? AND contrasena = ?";

        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setString(1, nombre);
            stmt.setString(2, contrasena);

            try (var rs = stmt.executeQuery()) {
                if (rs.next()) {
                    return new Usuario(
                            rs.getString("uuid"),
                            rs.getString("nombre"),
                            rs.getString("contrasena")
                    );
                } else {
                    return null;
                }
            }

        } catch (SQLException | ClassNotFoundException | IOException e) {
            System.err.println("Error al iniciar sesión: " + e.getMessage());
            return null;
        }
    }

}
