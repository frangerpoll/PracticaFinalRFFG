package controlador;

import modelo.Coche;
import utilidades.ConexionBD;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class ControladorCoche {

    public static boolean crearCoche(Coche coche, String uuidPropietario) {
        return crearCocheConCopropietario(coche, uuidPropietario, null);
    }

    public static boolean crearCocheConCopropietario(Coche coche, String uuidPropietario, String uuidCopropietario) {
        String sqlCoche = "INSERT INTO coches (marca, modelo, matricula, color, annio) VALUES (?, ?, ?, ?, ?)";
        String sqlRelacion = "INSERT INTO usuarios_coches (usuario_uuid, coche_id) VALUES (?, ?)";

        try (Connection conn = ConexionBD.conectar()) {
            conn.setAutoCommit(false);

            try (PreparedStatement stmtCoche = conn.prepareStatement(sqlCoche, Statement.RETURN_GENERATED_KEYS)) {
                stmtCoche.setString(1, coche.getMarca());
                stmtCoche.setString(2, coche.getModelo());
                stmtCoche.setString(3, coche.getMatricula());
                stmtCoche.setString(4, coche.getColor());
                stmtCoche.setInt(5, coche.getAnnio());
                stmtCoche.executeUpdate();

                ResultSet generatedKeys = stmtCoche.getGeneratedKeys();
                if (generatedKeys.next()) {
                    int cocheId = generatedKeys.getInt(1);

                    // Asignar propietario principal
                    try (PreparedStatement stmtRelacion = conn.prepareStatement(sqlRelacion)) {
                        stmtRelacion.setString(1, uuidPropietario);
                        stmtRelacion.setInt(2, cocheId);
                        stmtRelacion.executeUpdate();
                    }

                    // Si se añadió copropietario, verificar que exista y asignarlo
                    if (uuidCopropietario != null && !uuidCopropietario.isEmpty()) {
                        if (usuarioExiste(uuidCopropietario, conn)) {
                            try (PreparedStatement stmtRelacion2 = conn.prepareStatement(sqlRelacion)) {
                                stmtRelacion2.setString(1, uuidCopropietario);
                                stmtRelacion2.setInt(2, cocheId);
                                stmtRelacion2.executeUpdate();
                            }
                        } else {
                            conn.rollback();
                            return false; // UUID no válido
                        }
                    }

                    conn.commit();
                    return true;
                }
            }

            conn.rollback();
        } catch (SQLException e) {
            System.err.println("Error al crear coche con copropietario: " + e.getMessage());
        }

        return false;
    }

    private static boolean usuarioExiste(String uuid, Connection conn) throws SQLException {
        String sql = "SELECT 1 FROM usuarios WHERE uuid = ?";
        try (PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setString(1, uuid);
            ResultSet rs = stmt.executeQuery();
            return rs.next();
        }
    }

    public static List<Coche> obtenerCochesPorUsuario(String uuidUsuario) {
        List<Coche> lista = new ArrayList<>();

        String sql = """
                SELECT c.id, c.marca, c.modelo, c.matricula, c.color, c.annio
                FROM coches c
                JOIN usuarios_coches uc ON c.id = uc.coche_id
                WHERE uc.usuario_uuid = ?
                """;

        try (Connection conn = ConexionBD.conectar();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setString(1, uuidUsuario);
            ResultSet rs = stmt.executeQuery();

            while (rs.next()) {
                Coche c = new Coche(
                        rs.getString("marca"),
                        rs.getString("modelo"),
                        rs.getString("matricula"),
                        rs.getString("color"),
                        rs.getInt("annio")
                );
                c.setId(rs.getInt("id"));
                lista.add(c);
            }

        } catch (SQLException e) {
            System.err.println("Error al obtener coches del usuario: " + e.getMessage());
        }

        return lista;
    }
    public static boolean eliminarCochePorMatricula(String matricula) {
        String sql = "DELETE FROM coches WHERE matricula = ?";

        try (Connection conn = ConexionBD.conectar();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setString(1, matricula);
            int filas = stmt.executeUpdate();
            return filas > 0;

        } catch (SQLException e) {
            System.err.println("Error al eliminar coche: " + e.getMessage());
            return false;
        }
    }
    public static boolean actualizarCoche(Coche coche) {
        String sql = "UPDATE coches SET marca = ?, modelo = ?, color = ?, annio = ? WHERE matricula = ?";

        try (Connection conn = ConexionBD.conectar();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setString(1, coche.getMarca());
            stmt.setString(2, coche.getModelo());
            stmt.setString(3, coche.getColor());
            stmt.setInt(4, coche.getAnnio());
            stmt.setString(5, coche.getMatricula());

            int filas = stmt.executeUpdate();
            return filas > 0;

        } catch (SQLException e) {
            System.err.println("Error al actualizar coche: " + e.getMessage());
            return false;
            
           
        }
    }
    public static List<String> obtenerPropietariosDeCoche(int cocheId) {
        List<String> propietarios = new ArrayList<>();

        String sql = """
            SELECT u.nombre
            FROM usuarios u
            JOIN usuarios_coches uc ON u.uuid = uc.usuario_uuid
            WHERE uc.coche_id = ?
        """;

        try (Connection conn = ConexionBD.conectar();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setInt(1, cocheId);
            ResultSet rs = stmt.executeQuery();

            while (rs.next()) {
                propietarios.add(rs.getString("nombre"));
            }

        } catch (SQLException e) {
            System.err.println("Error al obtener propietarios: " + e.getMessage());
        }

        return propietarios;
    }



}
