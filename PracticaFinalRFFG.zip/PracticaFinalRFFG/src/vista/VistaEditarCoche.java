package vista;

import controlador.ControladorCoche;
import modelo.Coche;
import modelo.Usuario;

import javax.swing.*;
import java.awt.*;
import java.util.List;

public class VistaEditarCoche extends JFrame {
	
	private static final long serialVersionUID = 1L;

    public VistaEditarCoche(Usuario usuario) {
        setTitle("Editar coche");
        setSize(500, 350);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLocationRelativeTo(null);
        
     // Verificar conexión a la BBDD
        if (utilidades.ConexionBD.conectar() == null) {
            utilidades.GestorErrores.mostrarErrorConexion();
            dispose(); // Cierra esta ventana para evitar que siga cargando
            return;
        }


        List<Coche> coches = ControladorCoche.obtenerCochesPorUsuario(usuario.getUuid());

        if (coches.isEmpty()) {
            JOptionPane.showMessageDialog(this, "¡No hay coches para editar!");
            dispose();
            return;
        }

        DefaultListModel<Coche> modelo = new DefaultListModel<>();
        coches.forEach(modelo::addElement);

        JList<Coche> listaCoches = new JList<>(modelo);
        listaCoches.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);

        JButton botonEditar = new JButton("Editar seleccionado");
        botonEditar.addActionListener(e -> {
            Coche seleccionado = listaCoches.getSelectedValue();
            if (seleccionado != null) {
                new VistaFormularioEditarCoche(usuario, seleccionado).setVisible(true);
                this.dispose();
            }
        });

        add(new JScrollPane(listaCoches), BorderLayout.CENTER);
        add(botonEditar, BorderLayout.SOUTH);
    }
}
