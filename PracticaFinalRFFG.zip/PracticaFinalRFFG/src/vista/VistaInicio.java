package vista;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class VistaInicio extends JFrame {
	
	private static final long serialVersionUID = 1L;

    public VistaInicio() {
        setTitle("AhorraKart - Menú Principal");
        setSize(400, 250);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setLayout(new BorderLayout());
        
     // Verificar conexión a la BBDD
        if (utilidades.ConexionBD.conectar() == null) {
            utilidades.GestorErrores.mostrarErrorConexion();
            dispose(); // Cierra esta ventana para evitar que siga cargando
            return;
        }


        JLabel titulo = new JLabel("AhorraKart", SwingConstants.CENTER);
        titulo.setFont(new Font("Arial", Font.BOLD, 24));
        add(titulo, BorderLayout.NORTH);

        JPanel panelBotones = new JPanel();
        panelBotones.setLayout(new GridLayout(2, 1, 10, 10));

        JButton botonRegistro = new JButton("Registrarse");
        JButton botonLogin = new JButton("Iniciar sesión");

        panelBotones.add(botonRegistro);
        panelBotones.add(botonLogin);

        add(panelBotones, BorderLayout.CENTER);

        // Acción para registrar
        botonRegistro.addActionListener(e -> {
            new VistaRegistro(this).setVisible(true);
            this.setVisible(false);
        });

        // Acción para login
        botonLogin.addActionListener(e -> {
            new VistaLogin(this).setVisible(true);
            this.setVisible(false);
        });
    }
}
