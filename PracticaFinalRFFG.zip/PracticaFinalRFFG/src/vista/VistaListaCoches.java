package vista;

import controlador.ControladorCoche;
import modelo.Coche;
import modelo.Usuario;
import utilidades.GestorErrores;

import javax.swing.*;
import java.awt.*;
import java.util.List;

public class VistaListaCoches extends JFrame {
	
	private static final long serialVersionUID = 1L;

    public VistaListaCoches(Usuario usuario) {
        setTitle("Tus coches - AhorraKart");
        setSize(600, 350);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLocationRelativeTo(null);
        setLayout(new BorderLayout());

        // Verificar conexión
        if (utilidades.ConexionBD.conectar() == null) {
            GestorErrores.mostrarErrorConexion();
            dispose();
            return;
        }

        List<Coche> coches = ControladorCoche.obtenerCochesPorUsuario(usuario.getUuid());

        if (coches.isEmpty()) {
            JOptionPane.showMessageDialog(this, "¡No hay coches en tu lista!");
            dispose();
            return;
        }

        // Tabla de coches
        String[] columnas = {"Marca", "Modelo", "Matrícula", "Color", "Año"};
        String[][] datos = new String[coches.size()][5];

        for (int i = 0; i < coches.size(); i++) {
            Coche c = coches.get(i);
            datos[i][0] = c.getMarca();
            datos[i][1] = c.getModelo();
            datos[i][2] = c.getMatricula();
            datos[i][3] = c.getColor();
            datos[i][4] = String.valueOf(c.getAnnio());
        }

        JTable tabla = new JTable(datos, columnas);
        JScrollPane scrollPane = new JScrollPane(tabla);
        add(scrollPane, BorderLayout.CENTER);

        // Botón para ver detalles del coche seleccionado
        JButton btnVerDetalles = new JButton("Ver detalles");
        btnVerDetalles.addActionListener(e -> {
            int filaSeleccionada = tabla.getSelectedRow();
            if (filaSeleccionada >= 0) {
                Coche seleccionado = coches.get(filaSeleccionada);
                new VistaDetallesCoche(seleccionado).setVisible(true);
            } else {
                GestorErrores.mostrarAdvertencia("Sin selección", "Debes seleccionar un coche.");
            }
        });

        JPanel panelBoton = new JPanel();
        panelBoton.add(btnVerDetalles);
        add(panelBoton, BorderLayout.SOUTH);
    }
}
