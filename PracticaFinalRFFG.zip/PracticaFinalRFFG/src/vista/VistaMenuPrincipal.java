package vista;

import modelo.Usuario;

import javax.swing.*;
import java.awt.*;

public class VistaMenuPrincipal extends JFrame {
	
	private static final long serialVersionUID = 1L;

    public VistaMenuPrincipal(Usuario usuario) {
        setTitle("Panel Principal - AhorraKart");
        setSize(450, 400);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setLayout(new BorderLayout());
        
     // Verificar conexión a la BBDD
        if (utilidades.ConexionBD.conectar() == null) {
            utilidades.GestorErrores.mostrarErrorConexion();
            dispose(); // Cierra esta ventana para evitar que siga cargando
            return;
        }


        JLabel labelTitulo = new JLabel("Bienvenido, " + usuario.getNombre() + " ¿Qué quieres hacer?");
        labelTitulo.setHorizontalAlignment(SwingConstants.CENTER);
        labelTitulo.setFont(new Font("Arial", Font.BOLD, 16));
        add(labelTitulo, BorderLayout.NORTH);

        JPanel panelOpciones = new JPanel(new GridLayout(6, 1, 10, 10));

        JButton btnVerCoches = new JButton("Ver lista de coches");
        JButton btnCrearCoche = new JButton("Crear coche");
        JButton btnEditarCoche = new JButton("Editar coche");
        JButton btnEliminarCoche = new JButton("Eliminar coche");
        JButton btnAñadirGasto = new JButton("Añadir gasto de un coche");
        JButton btnVerGastos = new JButton("Ver gastos (tabla filtrable)");

        panelOpciones.add(btnVerCoches);
        panelOpciones.add(btnCrearCoche);
        panelOpciones.add(btnEditarCoche);
        panelOpciones.add(btnEliminarCoche);
        panelOpciones.add(btnAñadirGasto);
        panelOpciones.add(btnVerGastos);

        add(panelOpciones, BorderLayout.CENTER);

        // ACCIONES de cada botón
        btnVerCoches.addActionListener(e -> new VistaListaCoches(usuario).setVisible(true));
        btnCrearCoche.addActionListener(e -> new VistaCrearCoche(usuario).setVisible(true));
        btnEditarCoche.addActionListener(e -> new VistaEditarCoche(usuario).setVisible(true));
        btnEliminarCoche.addActionListener(e -> new VistaEliminarCoche(usuario).setVisible(true));
        btnAñadirGasto.addActionListener(e -> new VistaAñadirGasto(usuario).setVisible(true));
        btnVerGastos.addActionListener(e -> new VistaTablaGastos(usuario).setVisible(true));
    }
}
