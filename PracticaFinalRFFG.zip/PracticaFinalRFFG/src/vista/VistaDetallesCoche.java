package vista;

import controlador.ControladorCoche;
import modelo.Coche;

import javax.swing.*;
import java.awt.*;
import java.util.List;

public class VistaDetallesCoche extends JFrame {
	
	private static final long serialVersionUID = 1L;


    public VistaDetallesCoche(Coche coche) {
        setTitle("Detalles del coche");
        setSize(400, 300);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLocationRelativeTo(null);
        setLayout(new BorderLayout());

        // Panel de info del coche
        JPanel panelInfo = new JPanel(new GridLayout(5, 2, 5, 5));
        panelInfo.setBorder(BorderFactory.createTitledBorder("Información del coche"));

        panelInfo.add(new JLabel("Marca:"));      panelInfo.add(new JLabel(coche.getMarca()));
        panelInfo.add(new JLabel("Modelo:"));     panelInfo.add(new JLabel(coche.getModelo()));
        panelInfo.add(new JLabel("Matrícula:"));  panelInfo.add(new JLabel(coche.getMatricula()));
        panelInfo.add(new JLabel("Color:"));      panelInfo.add(new JLabel(coche.getColor()));
        panelInfo.add(new JLabel("Año:"));        panelInfo.add(new JLabel(String.valueOf(coche.getAnnio())));

        add(panelInfo, BorderLayout.NORTH);

        // Panel para copropietarios
        JTextArea areaPropietarios = new JTextArea("Cargando copropietarios...");
        areaPropietarios.setEditable(false);
        areaPropietarios.setBorder(BorderFactory.createTitledBorder("Copropietarios"));
        add(new JScrollPane(areaPropietarios), BorderLayout.CENTER);

        // 🔄 Cargar copropietarios en segundo plano
        new SwingWorker<List<String>, Void>() {
            @Override
            protected List<String> doInBackground() {
                return ControladorCoche.obtenerPropietariosDeCoche(coche.getId());
            }

            @Override
            protected void done() {
                try {
                    List<String> propietarios = get();
                    areaPropietarios.setText(""); // limpiar
                    if (propietarios.isEmpty()) {
                        areaPropietarios.setText("Sin copropietarios registrados.");
                    } else {
                        propietarios.forEach(nombre -> areaPropietarios.append("- " + nombre + "\n"));
                    }
                } catch (Exception e) {
                    areaPropietarios.setText("Error al cargar copropietarios.");
                }
            }
        }.execute();
    }
}
