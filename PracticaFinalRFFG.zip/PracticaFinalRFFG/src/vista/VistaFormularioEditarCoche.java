package vista;

import controlador.ControladorCoche;
import modelo.Coche;
import modelo.Usuario;

import javax.swing.*;
import java.awt.*;

public class VistaFormularioEditarCoche extends JFrame {
	
	private static final long serialVersionUID = 1L;

    public VistaFormularioEditarCoche(Usuario usuario, Coche coche) {
        setTitle("Editar Coche");
        setSize(400, 300);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLocationRelativeTo(null);
        setLayout(new GridLayout(6, 2, 5, 5));
        
     // Verificar conexión a la BBDD
        if (utilidades.ConexionBD.conectar() == null) {
            utilidades.GestorErrores.mostrarErrorConexion();
            dispose(); // Cierra esta ventana para evitar que siga cargando
            return;
        }


        JTextField campoMarca = new JTextField(coche.getMarca());
        JTextField campoModelo = new JTextField(coche.getModelo());
        JTextField campoMatricula = new JTextField(coche.getMatricula());
        campoMatricula.setEditable(false); // No editable ya que es clave única
        JTextField campoColor = new JTextField(coche.getColor());
        JTextField campoAnnio = new JTextField(String.valueOf(coche.getAnnio()));

        add(new JLabel("Marca:"));     add(campoMarca);
        add(new JLabel("Modelo:"));    add(campoModelo);
        add(new JLabel("Matrícula:")); add(campoMatricula);
        add(new JLabel("Color:"));     add(campoColor);
        add(new JLabel("Año:"));       add(campoAnnio);

        JButton botonGuardar = new JButton("Guardar cambios");
        add(new JLabel()); // Espacio
        add(botonGuardar);

        botonGuardar.addActionListener(e -> {
            try {
                Coche cocheActualizado = new Coche(
                    campoMarca.getText(),
                    campoModelo.getText(),
                    campoMatricula.getText(),
                    campoColor.getText(),
                    Integer.parseInt(campoAnnio.getText())
                );

                boolean exito = ControladorCoche.actualizarCoche(cocheActualizado);
                if (exito) {
                    JOptionPane.showMessageDialog(this, "Coche actualizado correctamente.");
                    dispose();
                } else {
                    JOptionPane.showMessageDialog(this, "Error al actualizar el coche.");
                }
            } catch (Exception ex) {
                JOptionPane.showMessageDialog(this, "Error en los datos: " + ex.getMessage());
            }
        });
    }
}
