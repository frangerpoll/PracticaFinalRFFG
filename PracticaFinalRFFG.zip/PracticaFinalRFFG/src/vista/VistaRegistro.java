package vista;

import modelo.Usuario;
import controlador.ControladorUsuario;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class VistaRegistro extends JFrame {
	
    private final JFrame ventanaAnterior;
    
    private static final long serialVersionUID = 1L;

    public VistaRegistro(JFrame ventanaAnterior) {
        this.ventanaAnterior = ventanaAnterior;

        setTitle("Registro - AhorraKart");
        setSize(400, 300);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setLayout(null);
        
     // Verificar conexión a la BBDD
        if (utilidades.ConexionBD.conectar() == null) {
            utilidades.GestorErrores.mostrarErrorConexion();
            dispose(); // Cierra esta ventana para evitar que siga cargando
            return;
        }


        JLabel labelTitulo = new JLabel("Registro de Usuario");
        labelTitulo.setBounds(120, 10, 200, 25);
        labelTitulo.setFont(new Font("Arial", Font.BOLD, 16));
        add(labelTitulo);

        JLabel labelNombre = new JLabel("Nombre:");
        labelNombre.setBounds(50, 60, 100, 25);
        add(labelNombre);

        JTextField campoNombre = new JTextField();
        campoNombre.setBounds(150, 60, 180, 25);
        add(campoNombre);

        JLabel labelContrasena = new JLabel("Contraseña:");
        labelContrasena.setBounds(50, 100, 100, 25);
        add(labelContrasena);

        JPasswordField campoContrasena = new JPasswordField();
        campoContrasena.setBounds(150, 100, 180, 25);
        add(campoContrasena);

        JButton botonRegistrar = new JButton("Registrar");
        botonRegistrar.setBounds(140, 160, 120, 30);
        add(botonRegistrar);

        botonRegistrar.addActionListener(e -> {
            String nombre = campoNombre.getText();
            String contrasena = new String(campoContrasena.getPassword());

            if (nombre.isEmpty() || contrasena.isEmpty()) {
                JOptionPane.showMessageDialog(this, "Todos los campos son obligatorios.");
                return;
            }

            Usuario usuario = new Usuario(nombre, contrasena);
            boolean registrado = ControladorUsuario.registrarUsuario(usuario);

            if (registrado) {
                JOptionPane.showMessageDialog(this,
                        "Registro exitoso.\nTu UUID es:\n" + usuario.getUuid() +
                                "\n¡Cópialo! Lo necesitarás para añadir co-propietarios.");
                this.dispose();
                ventanaAnterior.setVisible(true);
            } else {
                JOptionPane.showMessageDialog(this, "Error: usuario ya existe o fallo en la base de datos.");
            }
        });
    }
}
