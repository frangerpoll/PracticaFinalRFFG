package vista;

import controlador.ControladorCoche;
import controlador.ControladorGasto;
import modelo.Coche;
import modelo.Usuario;
import utilidades.GestorErrores;
import utilidades.Validador;

import javax.swing.*;
import java.awt.*;
import java.time.LocalDate;
import java.util.List;

public class VistaAñadirGasto extends JFrame {
	
	private static final long serialVersionUID = 1L;

    public VistaAñadirGasto(Usuario usuario) {
        setTitle("Añadir gasto");
        setSize(400, 350);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLocationRelativeTo(null);
        setLayout(new GridLayout(7, 2, 5, 5));
        
     // Verificar conexión a la BBDD
        if (utilidades.ConexionBD.conectar() == null) {
            utilidades.GestorErrores.mostrarErrorConexion();
            dispose(); // Cierra esta ventana para evitar que siga cargando
            return;
        }


        List<Coche> coches = ControladorCoche.obtenerCochesPorUsuario(usuario.getUuid());
        if (coches.isEmpty()) {
            JOptionPane.showMessageDialog(this, "No hay coches a los que añadir gastos.");
            dispose();
            return;
        }

        JComboBox<Coche> comboCoches = new JComboBox<>(coches.toArray(new Coche[0]));
        JComboBox<String> comboTipo = new JComboBox<>(new String[]{
                "echarGasolina", "revision", "cambioDeAceite", "itv", "otros"
        });
        JTextField campoKm = new JTextField();
        JTextField campoFecha = new JTextField(LocalDate.now().toString());
        JTextField campoImporte = new JTextField();
        JTextField campoDescripcion = new JTextField();

        add(new JLabel("Coche:"));        add(comboCoches);
        add(new JLabel("Tipo:"));         add(comboTipo);
        add(new JLabel("Kilometraje:"));  add(campoKm);
        add(new JLabel("Fecha:"));        add(campoFecha);
        add(new JLabel("Importe:"));      add(campoImporte);
        add(new JLabel("Descripción:"));  add(campoDescripcion);

        JButton btnGuardar = new JButton("Guardar gasto");
        add(new JLabel()); add(btnGuardar);

        btnGuardar.addActionListener(e -> {
            Coche coche = (Coche) comboCoches.getSelectedItem();
            String tipo = (String) comboTipo.getSelectedItem();
            String kmTexto = campoKm.getText().trim();
            String fecha = campoFecha.getText().trim();
            String importeTexto = campoImporte.getText().trim();
            String desc = campoDescripcion.getText().trim();

            if (Validador.estaVacio(kmTexto) || Validador.estaVacio(fecha) || Validador.estaVacio(importeTexto)) {
                GestorErrores.mostrarError("Campos obligatorios", "Debes completar todos los campos obligatorios.");
                return;
            }

            if (!Validador.esEntero(kmTexto)) {
                GestorErrores.mostrarError("Kilometraje inválido", "Introduce un número entero para el kilometraje.");
                return;
            }

            if (!Validador.esDecimal(importeTexto)) {
                GestorErrores.mostrarError("Importe inválido", "El importe debe ser un número decimal válido.");
                return;
            }

            boolean ok = controlador.ControladorGasto.crearGasto(
                    coche.getId(), tipo,
                    Integer.parseInt(kmTexto),
                    fecha,
                    Double.parseDouble(importeTexto),
                    desc
            );

            if (ok) {
                JOptionPane.showMessageDialog(this, "Gasto guardado correctamente.");
                dispose();
            } else {
                GestorErrores.mostrarError("Error al guardar", "No se pudo guardar el gasto en la base de datos.");
            }
        });

    }
}
