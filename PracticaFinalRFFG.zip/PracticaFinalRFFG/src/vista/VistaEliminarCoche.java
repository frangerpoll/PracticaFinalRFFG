package vista;

import controlador.ControladorCoche;
import modelo.Coche;
import modelo.Usuario;

import javax.swing.*;
import java.awt.*;
import java.util.List;

public class VistaEliminarCoche extends JFrame {
	
	private static final long serialVersionUID = 1L;
	
    public VistaEliminarCoche(Usuario usuario) {
        setTitle("Eliminar coche");
        setSize(400, 300);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLocationRelativeTo(null);
        
     // Verificar conexión a la BBDD
        if (utilidades.ConexionBD.conectar() == null) {
            utilidades.GestorErrores.mostrarErrorConexion();
            dispose(); // Cierra esta ventana para evitar que siga cargando
            return;
        }


        List<Coche> coches = ControladorCoche.obtenerCochesPorUsuario(usuario.getUuid());

        if (coches.isEmpty()) {
            JOptionPane.showMessageDialog(this, "No tienes coches que eliminar.");
            dispose();
            return;
        }

        DefaultListModel<Coche> modelo = new DefaultListModel<>();
        coches.forEach(modelo::addElement);

        JList<Coche> lista = new JList<>(modelo);
        lista.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);

        JButton btnEliminar = new JButton("Eliminar");
        btnEliminar.addActionListener(e -> {
            Coche seleccionado = lista.getSelectedValue();
            if (seleccionado != null) {
                boolean eliminado = ControladorCoche.eliminarCochePorMatricula(seleccionado.getMatricula());
                if (eliminado) {
                    JOptionPane.showMessageDialog(this, "Coche eliminado.");
                    dispose();
                } else {
                    JOptionPane.showMessageDialog(this, "No se pudo eliminar el coche.");
                }
            }
        });

        add(new JScrollPane(lista), BorderLayout.CENTER);
        add(btnEliminar, BorderLayout.SOUTH);
    }
}
