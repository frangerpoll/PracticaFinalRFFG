package vista;

import controlador.ControladorUsuario;
import modelo.Usuario;
import utilidades.GestorErrores;
import utilidades.Validador;

import javax.swing.*;
import java.awt.*;

public class VistaLogin extends JFrame {
    private final JFrame ventanaAnterior;
    
    private static final long serialVersionUID = 1L;


    public VistaLogin(JFrame ventanaAnterior) {
        this.ventanaAnterior = ventanaAnterior;

        setTitle("Iniciar Sesión - AhorraKart");
        setSize(400, 250);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setLayout(null);
        
     // Verificar conexión a la BBDD
        if (utilidades.ConexionBD.conectar() == null) {
            utilidades.GestorErrores.mostrarErrorConexion();
            dispose(); // Cierra esta ventana para evitar que siga cargando
            return;
        }


        JLabel titulo = new JLabel("Iniciar Sesión", SwingConstants.CENTER);
        titulo.setFont(new Font("Arial", Font.BOLD, 20));
        titulo.setBounds(100, 10, 200, 30);
        add(titulo);

        JLabel labelNombre = new JLabel("Nombre:");
        labelNombre.setBounds(50, 60, 100, 25);
        add(labelNombre);

        JTextField campoNombre = new JTextField();
        campoNombre.setBounds(150, 60, 180, 25);
        add(campoNombre);

        JLabel labelContrasena = new JLabel("Contraseña:");
        labelContrasena.setBounds(50, 100, 100, 25);
        add(labelContrasena);

        JPasswordField campoContrasena = new JPasswordField();
        campoContrasena.setBounds(150, 100, 180, 25);
        add(campoContrasena);

        JButton botonLogin = new JButton("Iniciar sesión");
        botonLogin.setBounds(130, 150, 140, 30);
        add(botonLogin);

        botonLogin.addActionListener(e -> {
            String nombre = campoNombre.getText();
            String contrasena = new String(campoContrasena.getPassword());

            if (Validador.estaVacio(nombre) || Validador.estaVacio(contrasena)) {
                GestorErrores.mostrarError("Campos vacíos", "Debes introducir nombre y contraseña.");
                return;
            }

            Usuario usuario = ControladorUsuario.iniciarSesion(nombre, contrasena);
            if (usuario != null) {
                JOptionPane.showMessageDialog(this, "Bienvenido, " + nombre + "!");
                new VistaMenuPrincipal(usuario).setVisible(true);
                this.dispose();
            } else {
                GestorErrores.mostrarError("Inicio fallido", "Nombre o contraseña incorrectos.");
            }
        });

    }
}
