package vista;

import controlador.ControladorGasto;
import modelo.Gasto;
import modelo.Usuario;
import modelo.Coche;
import controlador.ControladorCoche;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.util.List;
import java.util.stream.Collectors;

public class VistaTablaGastos extends JFrame {
	
	private static final long serialVersionUID = 1L;

    private JTable tabla;
    private DefaultTableModel modeloTabla;
    private JComboBox<Coche> comboCoches;
    private JTextField campoAnio;
    private JTextField campoKm;

    public VistaTablaGastos(Usuario usuario) {
        setTitle("Resumen de Gastos");
        setSize(800, 400);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLocationRelativeTo(null);
        setLayout(new BorderLayout());
        
     // Verificar conexión a la BBDD
        if (utilidades.ConexionBD.conectar() == null) {
            utilidades.GestorErrores.mostrarErrorConexion();
            dispose(); // Cierra esta ventana para evitar que siga cargando
            return;
        }


        JPanel panelFiltros = new JPanel(new FlowLayout());

        comboCoches = new JComboBox<>(ControladorCoche.obtenerCochesPorUsuario(usuario.getUuid()).toArray(new Coche[0]));
        campoAnio = new JTextField(5);
        campoKm = new JTextField(5);

        JButton botonFiltrar = new JButton("Filtrar");

        panelFiltros.add(new JLabel("Coche:"));
        panelFiltros.add(comboCoches);
        panelFiltros.add(new JLabel("Año:"));
        panelFiltros.add(campoAnio);
        panelFiltros.add(new JLabel("Km <= "));
        panelFiltros.add(campoKm);
        panelFiltros.add(botonFiltrar);

        add(panelFiltros, BorderLayout.NORTH);

        modeloTabla = new DefaultTableModel(new String[]{"Tipo", "Fecha", "Km", "Importe", "Descripción"}, 0);
        tabla = new JTable(modeloTabla);
        add(new JScrollPane(tabla), BorderLayout.CENTER);

        botonFiltrar.addActionListener(e -> cargarGastos());
    }

    private void cargarGastos() {
        modeloTabla.setRowCount(0); // limpiar

        Coche cocheSeleccionado = (Coche) comboCoches.getSelectedItem();
        if (cocheSeleccionado == null) return;

        List<Gasto> gastos = ControladorGasto.obtenerGastosPorCoche(cocheSeleccionado.getMatricula());

        String anio = campoAnio.getText().trim();
        String km = campoKm.getText().trim();

        gastos = gastos.stream().filter(g -> {
            boolean ok = true;
            if (!anio.isEmpty()) ok = ok && g.getFecha().startsWith(anio);
            if (!km.isEmpty()) {
                try {
                    ok = ok && g.getKilometraje() <= Integer.parseInt(km);
                } catch (NumberFormatException ex) {
                    // ignorar
                }
            }
            return ok;
        }).collect(Collectors.toList());

        for (Gasto g : gastos) {
            modeloTabla.addRow(new Object[]{
                g.getTipo(), g.getFecha(), g.getKilometraje(), g.getImporte(), g.getDescripcion()
            });
        }
    }
}
