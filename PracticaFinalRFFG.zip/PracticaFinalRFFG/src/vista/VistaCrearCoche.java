package vista;

import controlador.ControladorCoche;
import modelo.Coche;
import modelo.Usuario;
import utilidades.GestorErrores;
import utilidades.Validador;

import javax.swing.*;
import java.awt.*;

public class VistaCrearCoche extends JFrame {
	
	private static final long serialVersionUID = 1L;

    public VistaCrearCoche(Usuario usuario) {
        setTitle("Añadir coche");
        setSize(400, 350);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLocationRelativeTo(null);
        setLayout(new GridLayout(8, 2, 5, 5));

        JTextField campoMarca = new JTextField();
        JTextField campoModelo = new JTextField();
        JTextField campoMatricula = new JTextField();
        JTextField campoColor = new JTextField();
        JTextField campoAnnio = new JTextField();

        JTextField campoNombreCo = new JTextField();
        JTextField campoUUIDCo = new JTextField();

        add(new JLabel("Marca:"));       add(campoMarca);
        add(new JLabel("Modelo:"));      add(campoModelo);
        add(new JLabel("Matrícula:"));   add(campoMatricula);
        add(new JLabel("Color:"));       add(campoColor);
        add(new JLabel("Año:"));         add(campoAnnio);

        add(new JLabel("Copropietario (nombre):")); add(campoNombreCo);
        add(new JLabel("Copropietario (UUID):"));   add(campoUUIDCo);

        JButton botonGuardar = new JButton("Guardar coche");
        add(new JLabel()); // vacío
        add(botonGuardar);

        botonGuardar.addActionListener(e -> {
            String marca = campoMarca.getText();
            String modelo = campoModelo.getText();
            String matricula = campoMatricula.getText();
            String color = campoColor.getText();
            String annioTexto = campoAnnio.getText();

            String nombreCo = campoNombreCo.getText();
            String uuidCo = campoUUIDCo.getText();

            // ✅ Validaciones
            if (Validador.estaVacio(marca) || Validador.estaVacio(modelo) ||
                Validador.estaVacio(matricula) || Validador.estaVacio(color) ||
                Validador.estaVacio(annioTexto)) {
                GestorErrores.mostrarError("Campos obligatorios", "Todos los campos del coche son obligatorios.");
                return;
            }

            if (!Validador.esEntero(annioTexto)) {
                GestorErrores.mostrarError("Formato incorrecto", "El año debe ser un número válido.");
                return;
            }

            // Validar copropietario si se intenta añadir
            boolean coPropietarioLleno = !Validador.estaVacio(nombreCo) || !Validador.estaVacio(uuidCo);
            if (coPropietarioLleno && (Validador.estaVacio(nombreCo) || Validador.estaVacio(uuidCo))) {
                GestorErrores.mostrarError("Copropietario incompleto", "Debes introducir tanto el nombre como el UUID del copropietario.");
                return;
            }

            try {
                int annio = Integer.parseInt(annioTexto);
                Coche coche = new Coche(marca, modelo, matricula, color, annio);
                boolean ok = ControladorCoche.crearCocheConCopropietario(coche, usuario.getUuid(), uuidCo);

                if (ok) {
                    JOptionPane.showMessageDialog(this, "Coche creado correctamente.");
                    dispose();
                } else {
                    GestorErrores.mostrarError("UUID inválido", "El UUID del copropietario no existe.");
                }

            } catch (Exception ex) {
                GestorErrores.mostrarError("Error inesperado", "Ocurrió un error al guardar el coche: " + ex.getMessage());
            }
        });
    }
}
