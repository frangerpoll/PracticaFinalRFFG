-- Crear la base de datos

DROP database PracticaFinalRFFG;

CREATE DATABASE IF NOT EXISTS PracticaFinalRFFG;
USE PracticaFinalRFFG;

-- Tabla de usuarios
CREATE TABLE usuarios (
    uuid CHAR(36) PRIMARY KEY,
    nombre VARCHAR(50) UNIQUE NOT NULL,
    contrasena VARCHAR(255) NOT NULL
);

-- Tabla de coches
CREATE TABLE coches (
    id INT AUTO_INCREMENT PRIMARY KEY,
    marca VARCHAR(50) NOT NULL,
    modelo VARCHAR(50) NOT NULL,
    matricula VARCHAR(10) UNIQUE NOT NULL,
    color VARCHAR(30),
    annio INT NOT NULL
);

-- Relación muchos a muchos entre usuarios y coches
CREATE TABLE usuarios_coches (
    usuario_uuid CHAR(36),
    coche_id INT,
    PRIMARY KEY (usuario_uuid, coche_id),
    FOREIGN KEY (usuario_uuid) REFERENCES usuarios(uuid) ON DELETE CASCADE,
    FOREIGN KEY (coche_id) REFERENCES coches(id) ON DELETE CASCADE
);

-- Tabla de gastos
CREATE TABLE gastos (
    id INT AUTO_INCREMENT PRIMARY KEY,
    coche_id INT NOT NULL,
    tipo ENUM('echarGasolina', 'revision', 'itv', 'cambioDeAceite', 'otros') NOT NULL,
    kilometraje INT NOT NULL,
    fecha_gasto DATE NOT NULL,
    importe DECIMAL(10,2) NOT NULL,
    descripcion TEXT,
    FOREIGN KEY (coche_id) REFERENCES coches(id) ON DELETE CASCADE
);

-- Insertar usuarios
INSERT INTO usuarios (uuid, nombre, contrasena) VALUES 
('99b62b78-1b65-4573-aac9-1548d268bd03', 'Chopper', 'contraseña123'),
('96130b21-fc42-42c7-823a-82c757e850ac', 'Usopp', 'contraseña123'),
('2027c6ab-3aec-433e-a5a1-0e54c0518019', 'Franky', 'contraseña123'),
('9e0857a9-1d78-43a2-a44d-3e16777381ba', 'Doc', 'contraseña123'),
('6fc698ac-26a3-46b4-a903-ae289afa527b', 'Michael Knight', 'contraseña123');

-- Insertar coches
INSERT INTO coches (marca, modelo, matricula, color, annio) VALUES 
('BF', 'Brachio Tank V', '1234ABC', 'Dorado', 2020),
('BF', 'Kurosai FR-U IV', '2345BCD', 'Rojo', 2020),
('DeLorean', 'DMC-12', '3456CDE', 'gris', 3000),
('Pontiac', 'Firebird Trans-Am V8', '4567DEF', 'negro', 1982);

-- Insertar relaciones usuario-coche
-- 1234ABC (id 1)
INSERT INTO usuarios_coches (usuario_uuid, coche_id) VALUES 
('99b62b78-1b65-4573-aac9-1548d268bd03', 1),
('96130b21-fc42-42c7-823a-82c757e850ac', 1),
('2027c6ab-3aec-433e-a5a1-0e54c0518019', 1);

-- 2345BCD (id 2)
INSERT INTO usuarios_coches (usuario_uuid, coche_id) VALUES 
('2027c6ab-3aec-433e-a5a1-0e54c0518019', 2);

-- 3456CDE (id 3)
INSERT INTO usuarios_coches (usuario_uuid, coche_id) VALUES 
('9e0857a9-1d78-43a2-a44d-3e16777381ba', 3);

-- 4567DEF (id 4)
INSERT INTO usuarios_coches (usuario_uuid, coche_id) VALUES 
('6fc698ac-26a3-46b4-a903-ae289afa527b', 4);

-- Insertar gastos
INSERT INTO gastos (coche_id, tipo, kilometraje, fecha_gasto, importe, descripcion) VALUES 
(1, 'echarGasolina', 102000, '2024-05-10', 20.00, 'Franky Cola'),
(4, 'otros', 30000, '2020-03-09', 50.00, 'Actualización de la IA');
