package controlador;

import modelo.Usuario;
import utilidades.ConexionBD;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public class ControladorUsuario {

    public static boolean registrarUsuario(Usuario usuario) {
        String sql = "INSERT INTO usuarios (uuid, nombre, contrasena) VALUES (?, ?, ?)";

        try (Connection conn = ConexionBD.conectar();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setString(1, usuario.getUuid());
            stmt.setString(2, usuario.getNombre());
            stmt.setString(3, usuario.getContrasena());

            stmt.executeUpdate();
            return true;
        } catch (SQLException e) {
            System.err.println("❌ Error al registrar el usuario: " + e.getMessage());
            return false;
        }
    }
}
