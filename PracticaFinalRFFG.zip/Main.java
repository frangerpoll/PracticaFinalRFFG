import modelo.Usuario;
import controlador.ControladorUsuario;

import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.println("=== Registro de Usuario ===");
        System.out.print("Nombre: ");
        String nombre = scanner.nextLine();

        System.out.print("Contraseña: ");
        String contrasena = scanner.nextLine();

        Usuario usuario = new Usuario(nombre, contrasena);

        boolean registrado = ControladorUsuario.registrarUsuario(usuario);

        if (registrado) {
            System.out.println("✅ Usuario registrado correctamente.");
            System.out.println("🔐 Tu UUID es: " + usuario.getUuid());
        } else {
            System.out.println("❌ No se pudo registrar el usuario.");
        }

        scanner.close();
    }
}
